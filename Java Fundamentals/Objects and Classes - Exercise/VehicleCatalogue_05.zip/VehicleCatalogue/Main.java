package VehicleCatalogue;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String inputString = scanner.nextLine();

        List<Vehicle> vehiclesCatalogue = new ArrayList<>();

        while (!inputString.equals("End")) { // add in list

            String[] current = inputString.split(" ");


            Vehicle vehicle = new Vehicle(current[0], current[1], current[2],
                    Integer.parseInt(current[3]));

            vehiclesCatalogue.add(vehicle);
            inputString = scanner.nextLine();
        }

        while (true) { //  print data
            inputString = scanner.nextLine();
            if (inputString.equals("Close the Catalogue")) {
                break;
            }

            for (Vehicle vehicle : vehiclesCatalogue
            ) {
                if (vehicle.getModel().equals(inputString)) {
                    System.out.println(vehicle);
                }
            }
        }

        int carCount = 0;
        int truckCount = 0;
        double carHpSum = 0;
        double truckHpSum = 0;

        for (Vehicle vehicle : vehiclesCatalogue // sum Hp
        ) {
            if (vehicle.getTypeOfVehicle().equals("car")) {
                carHpSum += vehicle.getHorsePower();
                carCount++;
            } else {
                truckHpSum += vehicle.getHorsePower();
                truckCount++;
            }
        }

        double carAverageHp = carHpSum / carCount;
        double truckAverageHp = truckHpSum / truckCount;

        if (carCount == 0) carAverageHp = 0;
        if (truckCount == 0) truckAverageHp = 0;

        System.out.printf("Cars have average horsepower of: %.2f.%n", carAverageHp);
        System.out.printf("Trucks have average horsepower of: %.2f.", truckAverageHp);
    }
}
