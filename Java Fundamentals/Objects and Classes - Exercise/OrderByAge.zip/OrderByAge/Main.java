package OrderByAge;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<PersonData> personDataList = new ArrayList<>();

        while (true) {
            String[] inputData = scanner.nextLine().split(" ");
            if (inputData[0].equals("End")) {
                break;
            }
            PersonData personData = new PersonData(inputData[0], inputData[1], Integer.parseInt(inputData[2]));
            personDataList.add(personData);
        }

        personDataList.sort(Comparator.comparingInt(PersonData::getAge));

        for (PersonData person : personDataList
        ) {
            System.out.println(person);
            ;
        }
    }
}
