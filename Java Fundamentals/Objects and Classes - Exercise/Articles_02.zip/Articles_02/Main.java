package Articles_02;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String[] currentArticle = scanner.nextLine().split(", ");
        int n = Integer.parseInt(scanner.nextLine());

        List<Article> articles = new ArrayList<>();

        String title = currentArticle[0];
        String content = currentArticle[1];
        String auThor = currentArticle[2];
        Article article = new Article(title, content, auThor);

        for (int i = 1; i <= n; i++) {
            String[] command = scanner.nextLine().split(": ");

            switch (command[0]) {
                case "Edit":
                    article.edit(command[1]);
                    break;
                case "ChangeAuthor":
                    article.changeAuthor(command[1]);
                    break;
                case "Rename":
                    article.rename(command[1]);
                    break;
            }
        }
        System.out.printf("%s - %s: %s",article.getTitle(),article.getContent(),article.getAuthor());
    }
}
