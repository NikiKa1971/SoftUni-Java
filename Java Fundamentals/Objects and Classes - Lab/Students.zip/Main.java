import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        List<Student> students = new ArrayList<>();

        while (true) {
            String[] currentStudent = (scanner.nextLine().split(" "));

            if (currentStudent[0].equals("end")) {
                break;
            }

            String firstName=currentStudent[0];
            String lastName=currentStudent[1];
            int age= Integer.parseInt(currentStudent[2]);
            String homeTown=currentStudent[3];

            Student student=new Student(firstName,lastName,age,homeTown);
                    students.add(student);

        }
        String city = scanner.nextLine();

        for (Student student:students
             ) {
            if (student.getHomeTown().equals(city)){
                System.out.printf("%s %s is %d years old%n",student.getFirstName(), student.getLastName(), student.getAge());
            }
        }
    }
}
